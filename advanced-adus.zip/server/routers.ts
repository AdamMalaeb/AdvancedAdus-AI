import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { invokeLLM, listLLMModels } from "./_core/llm";
import { generateImage, listImageModels } from "./_core/imageGeneration";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { createAutomation, createIntegration, getAutomationsByUserId, getIntegrationsByUserId, updateAutomationStatus, updateIntegrationStatus } from "./db";
import { z } from "zod";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  adus: router({
    integrations: router({
      list: protectedProcedure.query(({ ctx }) => getIntegrationsByUserId(ctx.user.id)),
      create: protectedProcedure
        .input(z.object({ name: z.string().min(1).max(120), provider: z.string().min(1).max(80), notes: z.string().max(2000).optional() }))
        .mutation(({ ctx, input }) => createIntegration({ userId: ctx.user.id, name: input.name, provider: input.provider, notes: input.notes ?? null, status: "draft" })),
      setStatus: protectedProcedure
        .input(z.object({ id: z.number().int().positive(), status: z.enum(["draft", "connected", "paused"]) }))
        .mutation(({ ctx, input }) => updateIntegrationStatus(ctx.user.id, input.id, input.status)),
    }),
    automations: router({
      list: protectedProcedure.query(({ ctx }) => getAutomationsByUserId(ctx.user.id)),
      create: protectedProcedure
        .input(z.object({ name: z.string().min(1).max(160), trigger: z.string().min(1).max(2000), steps: z.string().min(1).max(8000) }))
        .mutation(({ ctx, input }) => createAutomation({ userId: ctx.user.id, name: input.name, trigger: input.trigger, steps: input.steps, status: "draft" })),
      setStatus: protectedProcedure
        .input(z.object({ id: z.number().int().positive(), status: z.enum(["draft", "pending_approval", "active", "paused"]) }))
        .mutation(({ ctx, input }) => updateAutomationStatus(ctx.user.id, input.id, input.status)),
    }),
    capabilities: protectedProcedure.query(async () => {
      const models = await listLLMModels();
      let imageModels = { models: [] as Array<{ model?: string; id?: string }> };
      try {
        imageModels = await listImageModels();
      } catch {
        // Keep the workspace available if the optional image service is unavailable.
      }
      return {
        access: "authenticated-users",
        chat: true,
        availableModelCount: models.data?.length ?? 0,
        imageGeneration: imageModels.models.length > 0,
        modules: [
          { id: "chat", label: "AI chat", status: "live", detail: "No app-imposed message cap" },
          { id: "research", label: "Web research", status: "live", detail: "Search and summarize public web pages" },
          { id: "studio", label: "Creative studio", status: imageModels.models.length > 0 ? "live" : "planned", detail: imageModels.models.length > 0 ? "Image generation is live" : "Image service unavailable" },
          { id: "build", label: "Build lab", status: "live", detail: "Generate code and website plans" },
          { id: "automations", label: "Automations", status: "approval", detail: "Draft workflows; execution needs approval" },
          { id: "integrations", label: "Integrations", status: "connection", detail: "Secure setup for external APIs" },
        ],
      };
    }),
    chat: protectedProcedure
      .input(z.object({
        message: z.string().min(1).max(12000),
        history: z.array(z.object({
          role: z.enum(["user", "assistant"]),
          content: z.string().max(20000),
        })).max(30).default([]),
      }))
      .mutation(async ({ input, ctx }) => {
        const history = input.history.map(item => ({
          role: item.role,
          content: item.content,
        }));

        const wantsImage = /(generate|create|make|produce|draw|render|show me|give me)[\s\S]{0,100}(image|photo|picture|illustration|poster|logo|visual)/i.test(input.message);

        const wantsResearch = /(research|search|latest|news|find out|look up|compare)/i.test(input.message);
        const wantsBuild = /(build|website|web site|landing page|app|html|react|code)/i.test(input.message);
        const wantsAutomation = /(automate|automation|workflow|every day|every week|schedule)/i.test(input.message);

        if (wantsImage) {
          try {
            const generated = await generateImage({
              prompt: `Create a polished final visual. ${input.message}. Do not add unwanted text, watermarks, borders, or UI chrome.`,
              quality: "medium",
            });
            return {
              content: generated.url ? "I created the image. You can open it below." : "The image service returned no file. Please try again.",
              model: "GPT Image 2",
              imageUrl: generated.url,
            };
          } catch (error) {
            return {
              content: `I could not generate that image right now. The image service returned: ${error instanceof Error ? error.message : "an unknown error"}`,
              model: "Adus image service",
            };
          }
        }

        if (wantsResearch) {
          try {
            const query = encodeURIComponent(input.message.replace(/^(research|search|look up)\s*/i, ""));
            const webResponse = await fetch(`https://html.duckduckgo.com/html/?q=${query}`, { headers: { "user-agent": "Adus research service" } });
            const html = await webResponse.text();
            const sourceText = html.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").slice(0, 14000);
            const research = await invokeLLM({
              model: "claude-sonnet-4-6",
              messages: [
                { role: "system", content: "You are Adus Research. Summarize the public search results below. Clearly label what is directly supported, include useful source titles or URLs if present, and say when evidence is limited. Do not invent facts." },
                { role: "user", content: `User request: ${input.message}\n\nPublic search results:\n${sourceText}` },
              ],
            });
            return { content: typeof research.choices?.[0]?.message?.content === "string" ? research.choices[0].message.content : "I found results but could not summarize them.", model: "Adus Research" };
          } catch (error) {
            return { content: `I could not reach the public web research service right now: ${error instanceof Error ? error.message : "unknown error"}`, model: "Adus Research" };
          }
        }

        if (wantsBuild) {
          const build = await invokeLLM({
            model: "claude-sonnet-4-6",
            thinking: { type: "enabled", budget_tokens: 1024 },
            messages: [
              { role: "system", content: "You are Adus Build Lab. Create practical, production-minded website or app plans and code. State what is implemented in your response versus what still needs deployment, credentials, or a connected service. Prefer accessible responsive HTML/CSS/React examples when code is requested." },
              { role: "user", content: input.message },
            ],
          });
          return { content: typeof build.choices?.[0]?.message?.content === "string" ? build.choices[0].message.content : "I could not produce a build response.", model: "Adus Build Lab" };
        }

        if (wantsAutomation) {
          const plan = await invokeLLM({
            model: "gpt-5-mini",
            messages: [
              { role: "system", content: "You are Adus Automation Designer. Turn the user's request into a concise workflow specification with trigger, steps, required connections, approval checkpoints, failure handling, and a clear statement that it is a draft until the user enables it." },
              { role: "user", content: input.message },
            ],
          });
          return { content: typeof plan.choices?.[0]?.message?.content === "string" ? plan.choices[0].message.content : "I could not draft that automation.", model: "Adus Automation Designer" };
        }

        const response = await invokeLLM({
          model: "claude-sonnet-4-6",
          thinking: { type: "enabled", budget_tokens: 1024 },
          messages: [
            {
              role: "system",
              content: `You are Adus, a powerful AI workspace available to authenticated users. Be direct, capable, warm, and honest about what you can and cannot access. You can help with research, writing, planning, code, websites, image/video concepts, files, and business operations. Never claim to have completed an external action unless a connected tool actually completed it. Ask for confirmation before publishing, deleting, purchasing, sending messages, changing account security, or using a new external integration. Respect each signed-in user's privacy and authorization. Current signed-in user: ${ctx.user.email ?? "authenticated user"}.`,
            },
            ...history,
            { role: "user", content: input.message },
          ],
        });

        const content = response.choices?.[0]?.message?.content;
        return {
          content: typeof content === "string" ? content : "I could not produce a text response this time. Please try again.",
          model: response.model ?? "Adus AI",
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
